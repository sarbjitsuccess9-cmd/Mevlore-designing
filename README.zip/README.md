# Melvore Design System v1.6.0 - UI Kit v3

No character animation. Everything is animated SVG (SMIL), outlined text (no font dependency), loop length 12s for layouts.

## Where things are
- `design-system/assets/svg/worlds_v3/<world>/layouts/` - full-screen 390x844 layouts: home, shop, product, bag. Goth home follows the dark crimson raven/widget vibe, Pixel home follows the pastel Y2K desktop-widget vibe; the other 10 worlds each have their own ambient background, hero art and typography.
- `design-system/assets/svg/worlds_v3/<world>/widgets/` - ~20 animated widgets per world (bg_ambient, hero_art, title_block, date_strip, player, tile_*, banner, product_card, nav_live, topbar, search, chips_row, coupon, order_steps, cta_add_to_bag, ...). Pixel also has os_window, angel_tile, icon_tile_*, cd_player, dock.
- `design-system/assets/svg/worlds_v2/<world>/` - 35 components + 10 icons (idle/active) per world.
- Manifest: `worlds.<slug>.kit.v3` and `kit.v2` in `design-system/live/manifest.json` (v1.2 keys untouched).
- Open `ui_kit_preview.html` to browse.
- Generators: `design-system/tools/ui-kit-generator` (python3 export3.py / export.py).

Note: layouts contain sample copy as outlined shapes (Sunday, Give It To Me ...). For production, use widgets + your own text, or regenerate with new copy via the generator.
